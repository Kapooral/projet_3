configure({
  configs: [
    './test.js'
  ]
});
